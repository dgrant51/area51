import hosters
import torrents

def get_hosters():
    return hosters.__all__
    
def get_torrents():
    return torrents.__all__